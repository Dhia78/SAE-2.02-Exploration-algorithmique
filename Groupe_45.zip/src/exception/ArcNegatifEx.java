package exception;

public class ArcNegatifEx extends RuntimeException {
	public ArcNegatifEx() {
		super();
	}
}
