package exception;

public class NoPathEx extends RuntimeException {
	public NoPathEx() {
		super();
	}
}
