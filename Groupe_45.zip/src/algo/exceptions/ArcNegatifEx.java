package algo.exceptions;

public class ArcNegatifEx extends RuntimeException{

    public ArcNegatifEx(){
        super();
    }
}
