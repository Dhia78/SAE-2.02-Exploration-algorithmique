package algo.exceptions;

public class NoPathEx extends RuntimeException{

    public NoPathEx(){
        super();
    }
}
